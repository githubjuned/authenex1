
import React from 'react';
import { DetectionResult } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from 'recharts';

interface ForensicReportProps {
  result: DetectionResult;
  onReset: () => void;
}

export const ForensicReport: React.FC<ForensicReportProps> = ({ result, onReset }) => {
  const pieData = [
    { name: 'AI Probability', value: result.aiPercentage, color: '#f43f5e' },
    { name: 'Human Probability', value: result.humanPercentage, color: '#10b981' }
  ];

  const radarData = result.categoryScores ? [
    { subject: 'Texture', A: result.categoryScores.texture, fullMark: 100 },
    { subject: 'Anatomy', A: result.categoryScores.anatomy, fullMark: 100 },
    { subject: 'Lighting', A: result.categoryScores.lighting, fullMark: 100 },
    { subject: 'Background', A: result.categoryScores.background, fullMark: 100 },
    { subject: 'Semantics', A: result.categoryScores.semantics, fullMark: 100 },
  ] : [];

  const getVerdictStyles = () => {
    switch(result.verdict) {
      case 'AI': return 'text-rose-500 border-rose-500/30 bg-rose-500/10';
      case 'HUMAN': return 'text-emerald-500 border-emerald-500/30 bg-emerald-500/10';
      default: return 'text-amber-500 border-amber-500/30 bg-amber-500/10';
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      
      {/* Header Result Summary */}
      <div className={`p-8 rounded-3xl border-2 text-center transition-all ${getVerdictStyles()} shadow-[0_0_40px_rgba(0,0,0,0.3)] relative overflow-hidden`}>
        {result.verdict === 'AI' && (
          <div className="absolute top-4 right-4 animate-bounce">
             <span className="bg-rose-600 text-white text-[10px] font-orbitron px-3 py-1 rounded-full shadow-lg border border-white/20 uppercase tracking-widest">Synthetic Detected</span>
          </div>
        )}
        
        <p className="text-xs font-orbitron tracking-[0.4em] uppercase mb-2 opacity-70">Forensic Scan Result</p>
        <h2 className="text-5xl font-black font-orbitron mb-2 tracking-tighter">
          {result.verdict === 'AI' ? 'SYNTHETIC' : result.verdict === 'HUMAN' ? 'AUTHENTIC' : 'SUSPICIOUS'}
        </h2>
        
        {result.verdict === 'AI' && result.metadata.potentialModel && (
          <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 rounded-xl backdrop-blur-md">
            <span className="text-[10px] font-orbitron text-slate-400 uppercase tracking-widest">Source Engine:</span>
            <span className="text-lg font-bold font-orbitron text-sky-400 neon-glow">{result.metadata.potentialModel}</span>
          </div>
        )}

        <div className="flex justify-center items-center gap-4 mt-6">
          <div className="h-px w-12 bg-current opacity-30"></div>
          <span className="text-sm font-orbitron uppercase tracking-widest">Confidence: {(result.confidence * 100).toFixed(1)}%</span>
          <div className="h-px w-12 bg-current opacity-30"></div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Graph Group 1: Composition (Pie Chart) */}
        <div className="glass-panel p-8 rounded-3xl flex flex-col items-center justify-center min-h-[450px]">
          <div className="text-center mb-8">
            <h3 className="font-orbitron text-lg text-slate-300">Compositional Integrity</h3>
            <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">Global probability distribution</p>
          </div>
          <div className="w-full h-72 relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={75}
                  outerRadius={110}
                  paddingAngle={8}
                  dataKey="value"
                  stroke="none"
                  animationBegin={0}
                  animationDuration={1500}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} fillOpacity={0.8} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '12px', fontSize: '12px' }}
                  itemStyle={{ color: '#f8fafc' }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-5xl font-black font-orbitron text-white">{Math.max(result.aiPercentage, result.humanPercentage)}%</span>
              <span className="text-[10px] text-slate-400 font-orbitron uppercase tracking-tighter">Primary Trace</span>
            </div>
          </div>
          
          <div className="mt-8 grid grid-cols-2 gap-8 w-full">
            <div className="p-4 rounded-2xl bg-rose-500/5 border border-rose-500/20 text-center">
              <p className="text-[10px] font-orbitron text-rose-500 uppercase mb-1">AI Score</p>
              <p className="text-2xl font-bold font-orbitron text-white">{result.aiPercentage}%</p>
            </div>
            <div className="p-4 rounded-2xl bg-emerald-500/5 border border-emerald-500/20 text-center">
              <p className="text-[10px] font-orbitron text-emerald-500 uppercase mb-1">Human Score</p>
              <p className="text-2xl font-bold font-orbitron text-white">{result.humanPercentage}%</p>
            </div>
          </div>
        </div>

        {/* Graph Group 2: Categorical Analysis (Radar Chart) */}
        <div className="glass-panel p-8 rounded-3xl flex flex-col items-center justify-center min-h-[450px]">
          <div className="text-center mb-8">
            <h3 className="font-orbitron text-lg text-slate-300">Synthetic Artifact Map</h3>
            <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">High area = High synthetic markers</p>
          </div>
          <div className="w-full h-72">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                <PolarGrid stroke="#334155" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 10, fontFamily: 'Orbitron' }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                <Radar
                  name="Synthetic Level"
                  dataKey="A"
                  stroke="#38bdf8"
                  fill="#38bdf8"
                  fillOpacity={0.4}
                  animationDuration={2000}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '12px', fontSize: '12px' }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
          
          <div className="mt-8 w-full p-4 rounded-2xl border border-slate-800 bg-black/20">
            <h4 className="text-[10px] font-orbitron text-sky-400 uppercase mb-3 tracking-widest">Dimension Readings</h4>
            <div className="flex flex-wrap gap-4 justify-between">
              {radarData.map((d, i) => (
                <div key={i} className="flex flex-col">
                  <span className="text-[9px] text-slate-500 font-orbitron uppercase">{d.subject}</span>
                  <span className="text-sm font-bold text-white">{d.A}/100</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Findings and Detailed Metadata */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-panel p-8 rounded-3xl border border-slate-800">
          <h4 className="font-orbitron text-sm text-sky-400 mb-6 flex items-center gap-2">
            <i className="fa-solid fa-dna text-sky-500"></i> Forensic Discovery Sequence
          </h4>
          <div className="space-y-4">
            {result.findings.map((finding, idx) => (
              <div key={idx} className="flex gap-4 p-4 rounded-xl bg-slate-900/40 border border-slate-800/50 group hover:border-sky-500/30 transition-all">
                <div className="w-8 h-8 rounded-full bg-sky-500/10 border border-sky-500/20 flex items-center justify-center shrink-0 text-sky-500 text-xs font-bold group-hover:bg-sky-500 group-hover:text-white transition-all">
                  {idx + 1}
                </div>
                <p className="text-sm text-slate-300 leading-relaxed pt-1">{finding}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-8">
          <div className="glass-panel p-8 rounded-3xl border border-slate-800">
            <h4 className="font-orbitron text-sm text-sky-400 mb-4 uppercase tracking-widest">Engine Metadata</h4>
            <div className="space-y-6">
              <div>
                <p className="text-[10px] font-orbitron text-slate-500 uppercase mb-1">Identified Model</p>
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${result.verdict === 'AI' ? 'bg-rose-500' : 'bg-emerald-500'} animate-pulse`}></div>
                  <p className="text-xl font-bold text-white truncate">
                    {result.verdict === 'AI' ? (result.metadata.potentialModel || 'Unknown Synthetic') : 'None (Authentic)'}
                  </p>
                </div>
              </div>
              <div className="h-px bg-slate-800"></div>
              <div>
                <p className="text-[10px] font-orbitron text-slate-500 uppercase mb-3">Detected Artifact Tags</p>
                <div className="flex flex-wrap gap-2">
                  {result.metadata.artifactsDetected.map((tag, i) => (
                    <span key={i} className="text-[9px] font-orbitron bg-slate-800 text-slate-400 px-2 py-1 rounded-md border border-slate-700 uppercase tracking-tighter">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <button 
            onClick={onReset}
            className="w-full py-6 bg-sky-600 hover:bg-sky-500 text-white rounded-3xl font-orbitron text-sm font-bold transition-all shadow-xl shadow-sky-600/30 flex items-center justify-center gap-4 group active:scale-95"
          >
            <i className="fa-solid fa-microscope group-hover:scale-125 transition-transform"></i>
            INITIATE NEW SCAN
          </button>
        </div>
      </div>
    </div>
  );
};
